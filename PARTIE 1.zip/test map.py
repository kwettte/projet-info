'''from PyQt5.QtWidgets import QApplication, QGraphicsView, QGraphicsScene
from PyQt5.QtGui import QPixmap

# Création d'une instance d'application PyQT5
app = QApplication([])

# Création d'un objet QGraphicsView
view = QGraphicsView()

# Création d'un objet QGraphicsScene
scene = QGraphicsScene()

# Ajout d'une image de plan à la scène
plan = QPixmap("C:/Users/lucie/Documents/0. ECOLE/ENSTA BRETAGNE/ANNEE 1/SEMESTRE 2/UE 2.1/INFO/TD 4/Ressources/arrierPlan.png")
scene.addPixmap(plan)

# Assignation de la scène à la vue
view.setScene(scene)

# Affichage de la vue
view.show()

# Exécution de l'application PyQT5
app.exec_()'''

from PIL import Image
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import matplotlib.pyplot as plt

img = Image.open(r'PLAN_ENSTA.jpg')
fig, ax = plt.subplots(subplot_kw={'projection': ccrs.PlateCarree()})
ax.imshow(img_arr, origin='upper', transform=ccrs.PlateCarree())
ax.add_feature(cfeature.BORDERS, linewidth=0.5, edgecolor='black')
ax.gridlines(draw_labels=True, linewidth=0.5, color='gray', alpha=0.5, linestyle='--')
plt.show()